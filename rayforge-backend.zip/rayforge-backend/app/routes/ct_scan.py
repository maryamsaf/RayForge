# app/routes/ct_scan.py
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
import os
import uuid
import zipfile
from pathlib import Path

from app.database.db import SessionLocal
from app.models.ct_scan import CTScan
from app.models.user import User
from app.schemas.ct_scan import CTScanUploadResponse
from app.routes.profile import get_current_user   # Reusing existing auth dependency

router = APIRouter(prefix="/ct-scans", tags=["CT Scans"])


def get_db():
    """Dependency to get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Allowed file extensions
ALLOWED_SINGLE_FILES = {".dcm", ".nii", ".nii.gz"}
ALLOWED_ZIP = {".zip"}

MAX_FILE_SIZE = 500 * 1024 * 1024   # 500 MB in bytes


@router.post("/upload", response_model=CTScanUploadResponse)
async def upload_ct_scan(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Upload CT Scan - Supports both:
      - Single file: .dcm, .nii, .nii.gz
      - Folder upload: .zip file containing multiple DICOM files
    """
    file_ext = Path(file.filename).suffix.lower()
    is_zip_upload = file_ext == ".zip"

    # ==================== VALIDATION ====================
    # Check file type
    if is_zip_upload:
        if file_ext not in ALLOWED_ZIP:
            raise HTTPException(status_code=400, detail="Only .zip files are allowed for folder upload.")
    else:
        if file_ext not in ALLOWED_SINGLE_FILES:
            raise HTTPException(
                status_code=400,
                detail="Unsupported file format. Allowed formats: .dcm, .nii, .nii.gz, or .zip (for DICOM folder)"
            )

    # Check file size
    contents = await file.read()
    file_size = len(contents)

    if file_size > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"File too large. Maximum allowed size is 500MB. "
                   f"Your file is {file_size / (1024*1024):.2f} MB"
        )

    # ==================== PREPARE STORAGE ====================
    base_dir = "uploads/ct_scans"
    user_dir = f"{base_dir}/{current_user.id}"
    os.makedirs(user_dir, exist_ok=True)

    unique_id = uuid.uuid4().hex

    if is_zip_upload:
        # ------------------- Handle ZIP (DICOM Folder) -------------------
        zip_filename = f"{current_user.id}_{unique_id}.zip"
        zip_path = f"{user_dir}/{zip_filename}"

        # Save the zip file
        with open(zip_path, "wb") as f:
            f.write(contents)

        # Extract the zip
        extract_path = f"{user_dir}/{unique_id}_dicom"
        os.makedirs(extract_path, exist_ok=True)

        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_path)
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid or corrupted ZIP file.")

        stored_path = extract_path
        file_type = "dicom"
        original_name = file.filename

    else:
        # ------------------- Handle Single File -------------------
        stored_filename = f"{current_user.id}_{unique_id}{file_ext}"
        stored_path = f"{user_dir}/{stored_filename}"

        with open(stored_path, "wb") as f:
            f.write(contents)

        file_type = "nifti" if ".nii" in file_ext else "dicom"
        original_name = file.filename

    # ==================== SAVE TO DATABASE ====================
    ct_scan = CTScan(
        user_id=current_user.id,
        original_filename=original_name,
        stored_path=stored_path,
        file_size=file_size,
        file_type=file_type,
        is_zip=is_zip_upload,
        status="uploaded"
    )

    db.add(ct_scan)
    db.commit()
    db.refresh(ct_scan)

    return CTScanUploadResponse(
        message="CT Scan uploaded successfully",
        scan_id=ct_scan.id,
        original_filename=original_name,
        file_type=file_type,
        is_zip=is_zip_upload,
        file_size_mb=round(file_size / (1024 * 1024), 2),
        status="uploaded"
    )