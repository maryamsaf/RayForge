# app/routes/password.py
from fastapi import APIRouter, HTTPException, Form, Depends
from sqlalchemy.orm import Session
from app.database.db import SessionLocal
from app.models.user import User
from app.utils.token import generate_password_reset_token, verify_password_reset_token
from app.utils.email import send_password_reset_email
from app.utils.hash import hash_password

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Step 1 — request reset link
@router.post("/forgot-password")
def forgot_password(email: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    token = generate_password_reset_token(email)
    # optionally save in DB if using PasswordReset table
    # db.add(PasswordReset(...))
    # db.commit()

    # send email asynchronously
    import asyncio
    asyncio.run(send_password_reset_email(email, token))
    return {"message": "Password reset link sent. Check your email."}

# Step 2 — reset password using token
@router.post("/reset-password")
def reset_password(token: str = Form(...), new_password: str = Form(...), db: Session = Depends(get_db)):
    email = verify_password_reset_token(token)
    if not email:
        raise HTTPException(status_code=400, detail="Invalid or expired token")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.password = hash_password(new_password)
    db.commit()
    return {"message": "Password updated successfully."}