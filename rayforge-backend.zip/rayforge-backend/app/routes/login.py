# app/routes/login.py
from fastapi import APIRouter, Depends, HTTPException, Form
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from jose import jwt

from app.database.db import SessionLocal
from app.models.user import User
from app.models.session import UserSession
from app.utils.hash import verify_password
from app.config import SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES

router = APIRouter()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_access_token(data: dict, expires_delta: timedelta | None = None):
    """Create JWT access token with custom expiration time"""
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=60))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


@router.post("/login")
def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    remember_me: bool = Form(False),
    db: Session = Depends(get_db)
):
    """
    User login endpoint.
    - If remember_me=False → Session expires in 60 minutes
    - If remember_me=True  → Session expires in 7 days
    """
    # Authenticate user
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.password):
        raise HTTPException(status_code=400, detail="Incorrect email or password")

    if not user.is_verified:
        raise HTTPException(status_code=400, detail="Email not verified. Please verify your account first.")

    # Set expiration time based on "Remember Me"
    if remember_me:
        expire_minutes = 7 * 24 * 60        # 7 days
    else:
        expire_minutes = ACCESS_TOKEN_EXPIRE_MINUTES                 # 30 minutes

    # Create JWT token
    access_token = create_access_token(
        data={"sub": user.email},
        expires_delta=timedelta(minutes=expire_minutes)
    )

    # Create session record in database
    session = UserSession(
        user_id=user.id,
        token=access_token,
        last_activity=datetime.utcnow(),
        expires_at=datetime.utcnow() + timedelta(minutes=expire_minutes)
    )

    db.add(session)
    db.commit()

    return {
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in_minutes": expire_minutes,
        "remember_me": remember_me,
        "message": f"Login successful. Session will expire in {expire_minutes} minutes."
    }