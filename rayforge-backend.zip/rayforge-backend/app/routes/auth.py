# app/routes/auth.py
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Form
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from app.database.db import SessionLocal
from app.models.user import User
from app.models.password_reset import PasswordReset
from app.schemas.user import UserCreate
from app.utils.hash import hash_password
from app.utils.validator import validate_password
from app.utils.email import send_verification_email_sync, send_password_reset_email_sync
from app.utils.token import generate_verification_token, verify_token, generate_password_reset_token, verify_password_reset_token

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ====================== REGISTER ======================
@router.post("/register")
def register(user: UserCreate, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    violations = validate_password(user.password)
    if violations:
        raise HTTPException(status_code=400, detail=violations)

    existing_user = db.query(User).filter(User.email == user.email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")

    hashed_password = hash_password(user.password)
    new_user = User(
        name=user.name,
        email=user.email,
        password=hashed_password,
        is_verified=False,
        pending_email=None
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    token = generate_verification_token(user.email)
    background_tasks.add_task(send_verification_email_sync, user.email, token)

    return {"message": "User registered successfully. Please check your email to verify your account."}


# ====================== RESEND VERIFICATION EMAIL ======================
@router.post("/resend-verification")
def resend_verification(email: str = Form(...), background_tasks: BackgroundTasks = None, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if user.is_verified:
        raise HTTPException(status_code=400, detail="Email is already verified")

    token = generate_verification_token(user.email)
    background_tasks.add_task(send_verification_email_sync, user.email, token)

    return {"message": "Verification email has been sent again. Please check your inbox."}


# ====================== VERIFY EMAIL (Fixed) ======================
@router.get("/verify-email")
def verify_email(token: str, db: Session = Depends(get_db)):
    email_from_token = verify_token(token)
    if not email_from_token:
        raise HTTPException(status_code=400, detail="Invalid or expired token")

    user = db.query(User).filter(
        (User.email == email_from_token) | (User.pending_email == email_from_token)
    ).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Handle email change case
    if user.pending_email == email_from_token:
        user.email = user.pending_email
        user.pending_email = None

    user.is_verified = True
    db.commit()

    return {"message": "Email verified successfully."}


# ====================== FORGOT PASSWORD ======================
@router.post("/forgot-password")
def forgot_password(email: str = Form(...), background_tasks: BackgroundTasks = None, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    token = generate_password_reset_token(user.email)

    reset_entry = PasswordReset(
        user_id=user.id,
        token=token,
        expires_at=datetime.utcnow() + timedelta(hours=1)
    )
    db.add(reset_entry)
    db.commit()

    background_tasks.add_task(send_password_reset_email_sync, user.email, token)
    return {"message": "Password reset email sent. Check your inbox."}


# ====================== VERIFY RESET PASSWORD ======================
@router.get("/verify-reset-password")
def verify_reset_password(token: str, db: Session = Depends(get_db)):
    email = verify_password_reset_token(token)
    if not email:
        raise HTTPException(status_code=400, detail="Invalid or expired token")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.verified_reset_password = True
    db.commit()
    return {"message": "Password reset link verified."}


# ====================== RESET PASSWORD ======================
@router.post("/reset-password")
def reset_password(email: str = Form(...), new_password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if not user.verified_reset_password:
        raise HTTPException(status_code=400, detail="Password reset not verified. Click the link first.")

    user.password = hash_password(new_password)
    user.verified_reset_password = False

    db.query(PasswordReset).filter(PasswordReset.user_id == user.id).delete()
    db.commit()

    return {"message": "Password reset successfully."}