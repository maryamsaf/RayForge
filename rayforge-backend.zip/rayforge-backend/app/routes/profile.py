# app/routes/profile.py
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from jose import jwt, JWTError, ExpiredSignatureError

from app.database.db import SessionLocal
from app.models.user import User
from app.schemas.user import UserUpdate, UserResponse
from app.utils.hash import hash_password
from app.utils.validator import validate_password
from app.utils.email import send_verification_email_sync
from app.utils.token import generate_verification_token
from app.config import SECRET_KEY, ALGORITHM

import shutil
import os
import uuid

router = APIRouter(tags=["Profile"])

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    """Get currently authenticated user"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if not email:
            raise HTTPException(status_code=401, detail="Invalid authentication token")
    except ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication token")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


# ====================== GET PROFILE ======================
@router.get("/", response_model=UserResponse)
def get_profile(current_user: User = Depends(get_current_user)):
    """Retrieve current user profile"""
    return current_user


# ====================== UPDATE PROFILE ======================
@router.put("/")
def update_profile(
    user_update: UserUpdate,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update name, password, or email (email change requires re-verification)"""
    user = current_user
    email_changed = False

    # Update Name
    if user_update.name and user_update.name.strip():
        user.name = user_update.name.strip()

    # Update Password
    if user_update.password:
        violations = validate_password(user_update.password)
        if violations:
            raise HTTPException(status_code=400, detail=violations)
        user.password = hash_password(user_update.password)

    # Update Email
    if user_update.email and user_update.email != user.email:
        existing_user = db.query(User).filter(User.email == user_update.email).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already in use")

        user.pending_email = user_update.email
        user.is_verified = False
        email_changed = True

        token = generate_verification_token(user_update.email)
        background_tasks.add_task(send_verification_email_sync, user_update.email, token)

    db.commit()
    db.refresh(user)

    # Clean response data
    user_data = {
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "is_verified": user.is_verified,
        "avatar_url": user.avatar_url
    }

    if email_changed:
        return {
            "message": "Profile updated successfully",
            "detail": "A verification link has been sent to your new email address. Please verify it to complete the change.",
            "user": user_data
        }
    else:
        return {
            "message": "Profile updated successfully",
            "user": user_data
        }


# ====================== UPLOAD AVATAR (with Old Avatar Deletion) ======================
@router.post("/avatar")
def upload_avatar(
    avatar: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Upload new profile picture and safely delete the old one if it exists"""
    
    # Validate file type
    if avatar.content_type not in ["image/jpeg", "image/png", "image/jpg"]:
        raise HTTPException(
            status_code=400,
            detail="Invalid file type. Only JPEG and PNG images are allowed."
        )

    # Validate file size (max 2MB)
    if avatar.size and avatar.size > 2 * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail="File too large. Maximum allowed size is 2MB."
        )

    # Ensure directory exists
    os.makedirs("uploads/avatars", exist_ok=True)

    # Generate unique filename for new avatar
    ext = os.path.splitext(avatar.filename)[1].lower()
    file_name = f"{current_user.id}_{uuid.uuid4().hex}{ext}"
    new_file_path = f"uploads/avatars/{file_name}"

    try:
        # Step 1: Save the new avatar file
        with open(new_file_path, "wb") as buffer:
            shutil.copyfileobj(avatar.file, buffer)

        # Step 2: Delete old avatar if it exists
        if current_user.avatar_url and os.path.exists(current_user.avatar_url):
            try:
                os.remove(current_user.avatar_url)
                print(f"✅ Old avatar deleted: {current_user.avatar_url}")
            except Exception as e:
                print(f"⚠️ Warning: Could not delete old avatar {current_user.avatar_url}. Error: {e}")
                # Do not fail the upload if old file deletion fails

        # Step 3: Update database with new avatar path
        current_user.avatar_url = new_file_path
        db.commit()
        db.refresh(current_user)

        # Prepare clean response
        user_data = {
            "id": current_user.id,
            "name": current_user.name,
            "email": current_user.email,
            "is_verified": current_user.is_verified,
            "avatar_url": current_user.avatar_url
        }

        return {
            "message": "Profile picture uploaded successfully",
            "user": user_data
        }

    except Exception as e:
        print(f"❌ Avatar upload error: {e}")
        raise HTTPException(status_code=500, detail="Failed to upload profile picture")