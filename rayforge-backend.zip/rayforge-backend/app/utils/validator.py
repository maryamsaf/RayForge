# rayforge-backend\app\utils\validator.py
import re

def validate_password(password: str):
    """
    Returns a list of violation messages. Empty list means password is valid.
    """
    violations = []

    if len(password) < 8:
        violations.append("Password must be at least 8 characters long")
    if not re.search(r"[A-Z]", password):
        violations.append("Password must include at least one uppercase letter")
    if not re.search(r"[a-z]", password):
        violations.append("Password must include at least one lowercase letter")
    if not re.search(r"\d", password):
        violations.append("Password must include at least one number")
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        violations.append("Password must include at least one special character")

    return violations