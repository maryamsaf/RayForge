# rayforge-backend\app\utils\token.py
from itsdangerous import URLSafeTimedSerializer
import os
from dotenv import load_dotenv

load_dotenv()

# Secret key
SECRET_KEY = os.getenv("SECRET_KEY", "supersecret")

# Serializer instance
serializer = URLSafeTimedSerializer(SECRET_KEY)


# ---------------------------
# EMAIL VERIFICATION TOKEN
# ---------------------------
def generate_verification_token(email: str) -> str:
    """
    Generate a signed token for email verification.
    """
    return serializer.dumps(email, salt="email-verification")


def verify_token(token: str, expiration: int = 3600) -> str | None:
    """
    Verify the email verification token.
    Expiration in seconds (default 1 hour).
    Returns email if valid, None if invalid or expired.
    """
    try:
        email = serializer.loads(token, salt="email-verification", max_age=expiration)
        return email
    except Exception:
        return None


# ---------------------------
# PASSWORD RESET TOKEN
# ---------------------------
def generate_password_reset_token(email: str) -> str:
    """
    Generate a signed token for password reset.
    """
    return serializer.dumps(email, salt="password-reset")


def verify_password_reset_token(token: str, expiration: int = 1800) -> str | None:
    """
    Verify the password reset token.
    Expiration in seconds (default 1 hour).
    Returns email if valid, None if invalid or expired.
    """
    try:
        email = serializer.loads(token, salt="password-reset", max_age=expiration)
        return email
    except Exception:
        return None