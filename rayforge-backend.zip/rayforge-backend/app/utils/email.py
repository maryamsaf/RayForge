# app/utils/email.py
import asyncio
import aiosmtplib
from email.message import EmailMessage

from app.config import (
    EMAIL_FROM,
    SMTP_USER,
    SMTP_PASSWORD,
    SMTP_HOST,
    SMTP_PORT,
    SMTP_TLS,
    SMTP_SSL,
)

# ====================== EMAIL VERIFICATION ======================
async def send_verification_email_async(to_email: str, token: str):
    """Send email verification link (used for both registration and email change)"""
    message = EmailMessage()
    message["From"] = EMAIL_FROM
    message["To"] = to_email
    message["Subject"] = "Verify your RayForge account"

    # IMPORTANT: Correct URL with /auth/ prefix (matches your router setup)
    verification_link = f"http://127.0.0.1:8000/auth/verify-email?token={token}"

    message.set_content(
        f"Hi there,\n\n"
        f"Please verify your email address by clicking the link below:\n\n"
        f"{verification_link}\n\n"
        f"This link will expire in 1 hour.\n\n"
        f"Thanks,\n"
        f"RayForge Team"
    )

    try:
        await aiosmtplib.send(
            message,
            hostname=SMTP_HOST,
            port=SMTP_PORT,
            start_tls=SMTP_TLS,
            use_tls=SMTP_SSL,
            username=SMTP_USER,
            password=SMTP_PASSWORD,
        )
    except Exception as e:
        print(f"Failed to send verification email to {to_email}: {e}")
        # In production, you might want to log this properly


def send_verification_email_sync(to_email: str, token: str):
    """Synchronous wrapper for background tasks"""
    asyncio.run(send_verification_email_async(to_email, token))


# ====================== PASSWORD RESET ======================
async def send_password_reset_email_async(to_email: str, token: str):
    """Send password reset verification link"""
    message = EmailMessage()
    message["From"] = EMAIL_FROM
    message["To"] = to_email
    message["Subject"] = "Reset your RayForge password"

    reset_link = f"http://127.0.0.1:8000/auth/verify-reset-password?token={token}"

    message.set_content(
        f"Hi there,\n\n"
        f"You requested a password reset for your RayForge account.\n\n"
        f"Click the link below to verify your password reset request:\n\n"
        f"{reset_link}\n\n"
        f"After clicking the link, you can reset your password using the /reset-password endpoint.\n\n"
        f"If you did not request this, please ignore this email.\n\n"
        f"This link will expire in 1 hour.\n\n"
        f"Thanks,\n"
        f"RayForge Team"
    )

    try:
        await aiosmtplib.send(
            message,
            hostname=SMTP_HOST,
            port=SMTP_PORT,
            start_tls=SMTP_TLS,
            use_tls=SMTP_SSL,
            username=SMTP_USER,
            password=SMTP_PASSWORD,
        )
    except Exception as e:
        print(f"Failed to send password reset email to {to_email}: {e}")


def send_password_reset_email_sync(to_email: str, token: str):
    """Synchronous wrapper for background tasks"""
    asyncio.run(send_password_reset_email_async(to_email, token))