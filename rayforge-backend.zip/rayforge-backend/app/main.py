# app/main.py
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.database.db import Base, engine

# Import all routers
from app.routes import auth, login, profile, ct_scan
from app.middleware.session import session_middleware

# ====================== DATABASE SETUP ======================
# Create all database tables on startup
Base.metadata.create_all(bind=engine)
# ===========================================================

# ====================== INITIALIZE APP ======================
app = FastAPI(
    title="RayForge API",
    version="0.1.0",
    description="Backend API for RayForge - CT Scan & 3D Model Platform"
)
# ===========================================================

# ====================== STATIC FILE SERVING ======================
# Allows frontend to access uploaded avatars and CT scans
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")
# ================================================================

# ====================== INCLUDE ROUTERS ======================
app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(login.router, prefix="/auth", tags=["Authentication"])
app.include_router(profile.router, prefix="/profile", tags=["Profile"])
app.include_router(ct_scan.router, prefix="/ct-scans", tags=["CT Scans"])
# =============================================================

# ====================== MIDDLEWARE ======================
# Session inactivity middleware
app.middleware("http")(session_middleware)
# =======================================================

# ====================== HEALTH CHECK ======================
@app.get("/health")
def health_check():
    """Simple health check endpoint"""
    return {"status": "healthy", "message": "RayForge API is running"}
# ==========================================================