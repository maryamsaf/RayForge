# app/config.py

# ---------------------------
# JWT Config
# ---------------------------
import secrets

SECRET_KEY = secrets.token_urlsafe(32)  # Randomly generated JWT secret key
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 #min


# ---------------------------
# Email Config
# ---------------------------
EMAIL_FROM = "name@gmail.com"
SMTP_USER = "name@gmail.com"
SMTP_PASSWORD = "abcd efgh ijkl mnop"  # Your Gmail App Password
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_TLS = True
SMTP_SSL = False