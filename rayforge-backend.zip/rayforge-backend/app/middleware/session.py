# app/middleware/session.py
from fastapi import Request, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from app.database.db import SessionLocal
from app.models.session import UserSession


async def session_middleware(request: Request, call_next):
    """
    Middleware to handle session inactivity.
    - User will be logged out after 30 minutes of inactivity.
    - Updates last_activity timestamp on every valid request.
    """
    db: Session = SessionLocal()
    token = None

    try:
        # Extract token from Authorization header
        authorization = request.headers.get("Authorization")
        if authorization and authorization.startswith("Bearer "):
            token = authorization.replace("Bearer ", "")

            if token:
                session = db.query(UserSession).filter(UserSession.token == token).first()

                if session:
                    # Check for inactivity (30 minutes)
                    inactivity_limit = timedelta(minutes=30)

                    if datetime.utcnow() > session.last_activity + inactivity_limit:
                        # Delete expired session
                        db.delete(session)
                        db.commit()
                        raise HTTPException(
                            status_code=401,
                            detail="Session expired due to inactivity (30 minutes). Please login again."
                        )

                    # Update last activity timestamp (extend session)
                    session.last_activity = datetime.utcnow()
                    db.commit()

    except Exception as e:
        # Log error but don't block the request
        print(f"Session middleware error: {e}")

    finally:
        # Always close the database session
        db.close()

    # Continue processing the request
    response = await call_next(request)
    return response