# app/models/session.py
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from app.database.db import Base
from datetime import datetime

class UserSession(Base):
    __tablename__ = "user_sessions"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    token = Column(String, unique=True, index=True)
    last_activity = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)