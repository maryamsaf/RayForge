# app/models/user.py
from sqlalchemy import Column, Integer, String, Boolean
from app.database.db import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password = Column(String(128), nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    verified_reset_password = Column(Boolean, default=False, nullable=False)
    
    # Fields for email change and avatar
    pending_email = Column(String, unique=True, index=True, nullable=True)
    avatar_url = Column(String, nullable=True)   # relative path: uploads/avatars/xxx.jpg