# app/models/ct_scan.py
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean
from datetime import datetime
from app.database.db import Base


class CTScan(Base):
    """
    Model to store information about uploaded CT Scan files.
    Supports both single files (NIfTI) and DICOM folders (uploaded as ZIP).
    """
    __tablename__ = "ct_scans"

    id = Column(Integer, primary_key=True, index=True)
    
    # Link to the user who uploaded the scan
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # Original name of the file/folder uploaded by user
    original_filename = Column(String, nullable=False)
    
    # Where the file or extracted folder is stored on disk
    stored_path = Column(String, nullable=False)
    
    # Size of the uploaded file in bytes
    file_size = Column(Integer, nullable=False)
    
    # Type of scan: 'dicom', 'nifti'
    file_type = Column(String, nullable=False)
    
    # Whether this upload was a ZIP file (DICOM folder)
    is_zip = Column(Boolean, default=False)
    
    # Current status of the scan
    status = Column(String, default="uploaded")   # uploaded, processing, completed, failed
    
    # Timestamps
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    processed_at = Column(DateTime, nullable=True)   # When 3D processing is done