# app/schemas/ct_scan.py
from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class CTScanUploadResponse(BaseModel):
    """
    Response returned after successfully uploading a CT Scan.
    """
    message: str
    scan_id: int
    original_filename: str
    file_type: str
    is_zip: bool
    file_size_mb: float
    status: str


class CTScanResponse(BaseModel):
    """
    General response for retrieving CT Scan information.
    """
    id: int
    original_filename: str
    file_type: str
    is_zip: bool
    file_size_mb: float
    status: str
    uploaded_at: datetime
    processed_at: Optional[datetime] = None

    class Config:
        from_attributes = True